package com.org.flagsreact.dao;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import com.org.flagsreact.model.Continent;
import com.org.flagsreact.service.impl.AppConfigureServiceImpl;


@Component
@Scope("singleton")
public class ContinentDAO {
	private Logger logger = LoggerFactory.getLogger(ContinentDAO.class);
	
	private List<Continent> continents = null;

	public List<Continent> getContinents() {
		return continents;
	}

	public void setContinents(List<Continent> continents) {
		this.continents = continents;
	}
	
	
	
}
