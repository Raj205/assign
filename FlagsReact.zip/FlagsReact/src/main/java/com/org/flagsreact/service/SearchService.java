package com.org.flagsreact.service;

import java.util.List;

import com.org.flagsreact.model.Continent;
import com.org.flagsreact.model.Country;

public interface SearchService {
	
	String performSearch(String searchStr);
	
	List<Continent> getContinents();
	
	List<Country> getCountries();

}
