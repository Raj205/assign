package com.org.flagsreact.search;

public interface Search {
	
	String performSearch(String searchCriteria);

}
