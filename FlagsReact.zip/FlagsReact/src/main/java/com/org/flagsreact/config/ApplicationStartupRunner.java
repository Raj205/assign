package com.org.flagsreact.config;


import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;


@Component
public class ApplicationStartupRunner implements CommandLineRunner {
	private Logger logger = LogManager.getLogger(ApplicationStartupRunner.class);
	
	@Autowired
	private AppConfig appConfig;
	
    @Override
    public void run(String... args) throws Exception {
        logger.info("ApplicationStartupRunner run method Started !!");
        
        logger.info("appConfig - " + appConfig);
        appConfig.config();
        //appcinfig.initialLoad(appConfigService);
        logger.info(" continentSearchService.list() called -->");
    }
}

