package com.org.flagsreact.model;

import java.util.List;


public class Continent {
	
	private String continent;
	private List<Country> countries;
	
	
	public String getContinent() {
		return continent;
	}
	public void setContinent(String continent) {
		this.continent = continent;
	}
	public List<Country> getCountries() {
		return countries;
	}
	public void setCountries(List<Country> countries) {
		this.countries = countries;
	}
	
	
	//Returns true if this.continentName  match with others
	@Override
    public boolean equals(Object o) { 
		
		// Returns true if references are same  
        if (o == this) { 
            return true; 
        } 
  
        // Check if o is an instance of Continent or not 
        //  "null instanceof [type]" also returns false 
        if (!(o instanceof Continent)) { 
            return false; 
        }
        
        Continent c = (Continent) o; 
        
        //Compares continent name with other 
        return this.getContinent().equalsIgnoreCase(c.getContinent());
	}

}