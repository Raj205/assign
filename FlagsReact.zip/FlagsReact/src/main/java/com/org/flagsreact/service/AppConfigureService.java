package com.org.flagsreact.service;

import java.util.List;

import com.org.flagsreact.model.Continent;

public interface AppConfigureService {
	
	public void loadContinents(List<Continent> continents);
	public void loadCountries(List<Continent> continents);

}
