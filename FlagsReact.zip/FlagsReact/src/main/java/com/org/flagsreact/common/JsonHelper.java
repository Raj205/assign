package com.org.flagsreact.common;

import java.io.File;
import java.io.IOException;
import java.util.List;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.org.flagsreact.model.Continent;

public class JsonHelper {
	
	private static ObjectMapper objectMapper;
	
	public static ObjectMapper getObjectMapper() {
		return objectMapper;
	}
	
	public static List<Continent> readContinentJson(File resourceFile) throws IOException, JsonParseException, JsonMappingException{		
		ObjectMapper mapper = new ObjectMapper();
		mapper.configure(JsonParser.Feature.ALLOW_UNQUOTED_CONTROL_CHARS, true);		
		TypeReference<List<Continent>> typeReference1 = new TypeReference<List<Continent>>() {};
		List<Continent> continents = mapper.readValue(resourceFile, typeReference1);
		return continents;
	}


}
