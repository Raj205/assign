package com.org.flagsreact.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.org.flagsreact.model.Continent;
import com.org.flagsreact.service.SearchService;


@RestController
@RequestMapping("/flag")
public class SearchController {
	
	
	@Autowired
	SearchService searchService;
	
	@RequestMapping("/")
	public List<Continent> conList(){
		
		List<Continent> continents = searchService.getContinents();
		
		return continents;
	}
	
	@RequestMapping("/{searchStr}")
	public String findOne(@PathVariable String searchStr){	
		
		String returnStr = searchService.performSearch(searchStr);
		
		if(null == returnStr || returnStr.equals("")) {
			returnStr = "{No result found}";
		}
		
		return returnStr;
	}

}
