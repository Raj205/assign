package com.org.flagsreact.model;


public class Country {
	
	private String name;
	private String flag;
	
	//private Blob b;
	
	public String getName() {
		return name;
	}
	
	public void setName(String name) {
		this.name = name;
	}
	
	public String getFlag() {
		return flag;
	}
	
	public void setFlag(String flag) {
		this.flag = flag;
	}
	
	
	//Returns true if this.name  match with others
	@Override
    public boolean equals(Object o) { 
		
		// Returns true if references are same   
        if (o == this) { 
            return true; 
        } 
  
         // Check if o is an instance of Continent or not 
        //  "null instanceof [type]" also returns false 
        if (!(o instanceof Country)) { 
            return false; 
        }
        
        Country c = (Country) o; 
        
        return this.getName().equalsIgnoreCase(c.getName());
	}
	
}

