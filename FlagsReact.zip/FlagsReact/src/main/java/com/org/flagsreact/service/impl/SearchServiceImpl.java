package com.org.flagsreact.service.impl;

import java.util.ArrayList;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.org.flagsreact.dao.ContinentDAO;
import com.org.flagsreact.dao.CountryDAO;
import com.org.flagsreact.model.Continent;
import com.org.flagsreact.model.Country;
import com.org.flagsreact.search.Search;
import com.org.flagsreact.service.SearchService;


@Service
public class SearchServiceImpl implements SearchService {
	
	private Logger log = LogManager.getLogger(SearchServiceImpl.class);
	
	@Autowired
	Search countrySearch;
	
	@Autowired
	Search flagSearch;
	
	@Autowired
	ContinentDAO cointentDAO;
	
	@Autowired
	CountryDAO countryDAO;

	@Override
	public String performSearch(String searchStr) {
		List<Search> cearchCriteria = new ArrayList<Search>();
		cearchCriteria.add(countrySearch);
		cearchCriteria.add(flagSearch);
		String jsonStr = null;
		
		for(int i = 0; i < cearchCriteria.size(); i++) {
			Search searchCriterai =  cearchCriteria.get(i);
			if(null == jsonStr) {
				jsonStr = searchCriterai.performSearch(searchStr);
			}
		}

		return jsonStr;
	}

	@Override
	public List<Continent> getContinents() {
		
		return cointentDAO.getContinents();
	}

	@Override
	public List<Country> getCountries() {
		
		return countryDAO.getCountries();
	}

}
