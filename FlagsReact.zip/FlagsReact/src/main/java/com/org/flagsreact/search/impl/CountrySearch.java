package com.org.flagsreact.search.impl;

import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.org.flagsreact.dao.ContinentDAO;
import com.org.flagsreact.model.Continent;
import com.org.flagsreact.model.Country;
import com.org.flagsreact.search.Search;



@Component
public class CountrySearch implements Search {
	
	private Logger logger = LogManager.getLogger(CountrySearch.class);
	
	@Autowired
	ContinentDAO continentDAO;

	@Override
	public String performSearch(String searchCriteria) {
		List<Continent> continents = continentDAO.getContinents();
		Continent c = new Continent();
		Continent found;
		String jsonStr = null;
		c.setContinent(searchCriteria);
		
		logger.info("CountrySearch>>");
		logger.info("searchCriteria  " + searchCriteria);
		logger.info("continents - " + continents);
		
		
		if(continents.contains(c)) {
			found = continents.get(continents.lastIndexOf(c));
			List<Country> countries = found.getCountries();
			logger.info("countries found "  + countries);
			try{				
				ObjectMapper mapper = new ObjectMapper();
				jsonStr = mapper.writeValueAsString(found.getCountries());
				logger.info("jsonStr - " + jsonStr);
			}catch(Exception ex){
				logger.info(ex.getMessage());
			}
		}
		return jsonStr;
	}

}
