package com.org.flagsreact.config;

import java.io.File;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ClassPathResource;
import org.springframework.stereotype.Component;

import com.org.flagsreact.common.JsonHelper;
import com.org.flagsreact.model.Continent;
import com.org.flagsreact.service.AppConfigureService;

@Component
public class AppConfig {
	
	private Logger logger = LogManager.getLogger(AppConfig.class);
	
	@Autowired
	AppConfigureService appConfigureService;
	
	public void config() throws Exception {
		logger.info("config() >>"); 
		loadContinents();
	}
	
	public void loadContinents() throws Exception {
		logger.info("loadContinents() >>");
		File resourceFile = new ClassPathResource(AppConstants.CONTINENTS_JSON).getFile();
		List<Continent> continents = JsonHelper.readContinentJson(resourceFile);
		appConfigureService.loadContinents(continents);
		appConfigureService.loadCountries(continents);
	}
}
