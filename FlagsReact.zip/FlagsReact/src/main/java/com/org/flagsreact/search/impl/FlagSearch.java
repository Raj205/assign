package com.org.flagsreact.search.impl;

import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.org.flagsreact.dao.CountryDAO;
import com.org.flagsreact.model.Country;
import com.org.flagsreact.search.Search;


@Component
public class FlagSearch implements Search{
	
	private Logger logger = LogManager.getLogger(FlagSearch.class);
	
	@Autowired
	CountryDAO countryDAO;

	@Override
	public String performSearch(String searchCriteria) {
		List<Country> continents = countryDAO.getCountries();
		Country c = new Country();
		Country found;
		String jsonStr = null;
		c.setName(searchCriteria);
		if(continents.contains(c)) {
			found = continents.get(continents.lastIndexOf(c));
			jsonStr = found.getFlag();
			logger.info("Flag " + jsonStr);
		}
		return jsonStr;
	}
}
