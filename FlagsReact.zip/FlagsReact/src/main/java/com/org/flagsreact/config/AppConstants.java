package com.org.flagsreact.config;

public class AppConstants {
	
	private AppConstants(){
		
	}
	
	public static final String CONTINENTS_JSON = "continents.json";

}
