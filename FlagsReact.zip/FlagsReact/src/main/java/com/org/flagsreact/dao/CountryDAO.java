package com.org.flagsreact.dao;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import com.org.flagsreact.model.Country;

@Component
@Scope("singleton")
public class CountryDAO {
	
	private Logger logger = LoggerFactory.getLogger(CountryDAO.class);
	
	private List<Country> countries;

	public List<Country> getCountries() {
		return countries;
	}

	public void setCountries(List<Country> countries) {
		this.countries = countries;
	}
}
