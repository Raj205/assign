package com.org.flagsreact;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.junit4.SpringRunner;

import com.org.flagsreact.dao.ContinentDAO;
import com.org.flagsreact.dao.CountryDAO;
import com.org.flagsreact.model.Continent;
import com.org.flagsreact.model.Country;
import com.org.flagsreact.search.Search;
import com.org.flagsreact.service.SearchService;

@RunWith(SpringRunner.class)
@SpringBootTest
class FlagsReactApplicationTests {
	
	@Autowired
	private SearchService searchService;
	
	@MockBean
	private CountryDAO countryDAO;
	
	@MockBean
	private ContinentDAO continentDAO;
	
	@Autowired
	private Search countrySearch;
	
	@Autowired
	private Search flagSearch;
	
	
	@Test
	public void performSearchTest() {
		List<Continent> continents = new ArrayList<Continent>();
		Continent continent = new Continent();
		continent.setContinent("America");
		continents.add(continent);
		List<Country> countries = new ArrayList<Country>();
		Country country = new Country();
		country.setName("USA");
		country.setFlag("us");
		countries.add(country);
		continent.setCountries(countries);
		
		when(continentDAO.getContinents()).thenReturn(continents);
		
		assertEquals("[{\"name\":\"USA\",\"flag\":\"us\"}]", countrySearch.performSearch("America"));
	}
}
